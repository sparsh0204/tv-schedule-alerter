EMAIL='YOUR_EMAIL' #Enter your email id from which you want to send mail
PASSWORD='YOUR_EMAIL_PASSWORD' # Password of that email id
DATABASE_HOST='MYSQL_DATABASE_HOST' # Mysql database host
DATABASE_USER='MYSQL_DATABASE_USER' # Mysql database user
DATABASE_PASSWORD='MYSQL_DATABASE_PASSWORD' # mysql database password
